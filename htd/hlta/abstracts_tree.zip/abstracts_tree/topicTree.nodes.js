var nodes = [{
  id: "Z35", text: "0.217 ambiental gestion recursos sector economico urbano territorio", data: { name: "Z35", level: 3, percentage: 0.2169860552846549 }, children: [{
      id: "Z217", text: "0.081 ambiental ambiente sostenible residuos economica emisiones alto", data: { name: "Z217", level: 2, percentage: 0.08087960957712892 }, children: [{
          id: "Z151", text: "0.206 ambiente sostenible emisiones bacterias interaccion superior tipo", data: { name: "Z151", level: 1, percentage: 0.20594256236954578 }, children: []
        }, {
          id: "Z152", text: "0.072 ambiental residuos economica alto calidad-vida convencional medico", data: { name: "Z152", level: 1, percentage: 0.07227862919691756 }, children: []
        }]
    }, {
      id: "Z219", text: "0.093 gestion sector organizaciones mercado procesos organizacional competitividad", data: { name: "Z219", level: 2, percentage: 0.09298013884396542 }, children: [{
          id: "Z158", text: "0.101 organizaciones procesos enfoque productos costos", data: { name: "Z158", level: 1, percentage: 0.10123157023644686 }, children: []
        }, {
          id: "Z156", text: "0.181 gestion administracion participacion practicas proposito superficie caracter", data: { name: "Z156", level: 1, percentage: 0.18119363777916347 }, children: []
        }, {
          id: "Z157", text: "0.101 sector mercado organizacional competitividad manizales elemento", data: { name: "Z157", level: 1, percentage: 0.1013397049231736 }, children: []
        }]
    }, {
      id: "Z218", text: "0.135 indicadores metodologia plan planeacion metodologias integral regional", data: { name: "Z218", level: 2, percentage: 0.1348969293459222 }, children: [{
          id: "Z155", text: "0.116 plan planeacion regional accion proteccion conflicto central", data: { name: "Z155", level: 1, percentage: 0.11632576676654513 }, children: []
        }, {
          id: "Z154", text: "0.000 metodologias metodologia", data: { name: "Z154", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z153", text: "0.338 indicadores integral niveles partir serie plantea ademas", data: { name: "Z153", level: 1, percentage: 0.3375718602618236 }, children: []
        }]
    }, {
      id: "Z220", text: "0.136 economico empresas economia debe servicios deben caso", data: { name: "Z220", level: 2, percentage: 0.13562616432787078 }, children: [{
          id: "Z163", text: "0.094 debe deben existen dentro", data: { name: "Z163", level: 1, percentage: 0.09397319188391016 }, children: []
        }, {
          id: "Z166", text: "0.000 efectividad costo", data: { name: "Z166", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z165", text: "0.140 ser alternativas busqueda final", data: { name: "Z165", level: 1, percentage: 0.14017713271612675 }, children: []
        }, {
          id: "Z159", text: "0.187 economico empresas necesidades derechos adolescentes", data: { name: "Z159", level: 1, percentage: 0.18718072576853934 }, children: []
        }, {
          id: "Z162", text: "0.181 forma tal general orden medida", data: { name: "Z162", level: 1, percentage: 0.1813802568099314 }, children: []
        }, {
          id: "Z160", text: "0.156 economia servicios caso nacional paises asi razon", data: { name: "Z160", level: 1, percentage: 0.15585114704221054 }, children: []
        }, {
          id: "Z167", text: "0.062 demanda electrico funcionamiento cantidad", data: { name: "Z167", level: 1, percentage: 0.06200280037991977 }, children: []
        }, {
          id: "Z164", text: "0.177 requiere toma-decisiones grandes adecuado hacen formulacion buena", data: { name: "Z164", level: 1, percentage: 0.17661739586928815 }, children: []
        }, {
          id: "Z161", text: "0.000 actualidad aun", data: { name: "Z161", level: 1, percentage: 0.0 }, children: []
        }]
    }, {
      id: "Z216", text: "0.058 territorio urbano medellin territorial habitat espacio sino", data: { name: "Z216", level: 2, percentage: 0.058360143233272405 }, children: [{
          id: "Z149", text: "0.066 manera siguiente dia posibilidad especifico estudiar condicione", data: { name: "Z149", level: 1, percentage: 0.0659905714039558 }, children: []
        }, {
          id: "Z148", text: "0.068 territorio espacio memoria calculo", data: { name: "Z148", level: 1, percentage: 0.06780028002470943 }, children: []
        }, {
          id: "Z147", text: "0.085 medellin territorial estudio-caso sede", data: { name: "Z147", level: 1, percentage: 0.08463818693461997 }, children: []
        }, {
          id: "Z150", text: "0.216 sino sociedad decir violencia instrumentos especy parametro", data: { name: "Z150", level: 1, percentage: 0.21617936762374923 }, children: []
        }, {
          id: "Z146", text: "0.030 urbano habitat natural futuro plazo disponible pueden-ser", data: { name: "Z146", level: 1, percentage: 0.03039479106526788 }, children: []
        }]
    }, {
      id: "Z215", text: "0.092 recursos naturales recurso conservacion apoyo creacion unidades", data: { name: "Z215", level: 2, percentage: 0.09210049089799244 }, children: [{
          id: "Z144", text: "0.085 recurso apoyo creacion unidades experimento basada presente-investigacion", data: { name: "Z144", level: 1, percentage: 0.08478484018492943 }, children: []
        }, {
          id: "Z145", text: "0.038 recursos naturales conservacion", data: { name: "Z145", level: 1, percentage: 0.0375708978967791 }, children: []
        }]
    }]
}, {
  id: "Z37", text: "0.065 especies especie genetica genero cultivos muestras diversidad", data: { name: "Z37", level: 3, percentage: 0.06517049306024028 }, children: [{
      id: "Z232", text: "0.203 realizo muestras cultivos porcentaje mostro rendimiento mientras", data: { name: "Z232", level: 2, percentage: 0.20282615790457767 }, children: [{
          id: "Z1126", text: "0.058 cultivos mientras arroz papa", data: { name: "Z1126", level: 1, percentage: 0.05827706247513369 }, children: []
        }, {
          id: "Z1129", text: "0.000 mayoria solo", data: { name: "Z1129", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1125", text: "0.089 aceite extraccion adicionalmente", data: { name: "Z1125", level: 1, percentage: 0.08852678619165424 }, children: []
        }, {
          id: "Z1128", text: "0.214 realizo muestras porcentaje mostro rendimiento ensayo obtuvo", data: { name: "Z1128", level: 1, percentage: 0.2141667278075628 }, children: []
        }, {
          id: "Z1127", text: "0.077 llevo expresion sexual mujere", data: { name: "Z1127", level: 1, percentage: 0.07735902624685838 }, children: []
        }]
    }, {
      id: "Z231", text: "0.051 genetica presencia genetico gene celulas asociadas varios", data: { name: "Z231", level: 2, percentage: 0.05087220125660707 }, children: [{
          id: "Z1124", text: "0.000 genetica genetico", data: { name: "Z1124", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1123", text: "0.089 presencia gene celulas asociadas varios", data: { name: "Z1123", level: 1, percentage: 0.0885601392862001 }, children: []
        }]
    }, {
      id: "Z230", text: "0.105 region rio regresion fuente muestreo fuentes aguas", data: { name: "Z230", level: 2, percentage: 0.10512018174152558 }, children: [{
          id: "Z1117", text: "0.204 fuente fuentes debido importancia anterior pais", data: { name: "Z1117", level: 1, percentage: 0.2038445916866239 }, children: []
        }, {
          id: "Z1122", text: "0.209 prueba significativo comparacion estadistica baja realizacion variabilidad", data: { name: "Z1122", level: 1, percentage: 0.20939219105551476 }, children: []
        }, {
          id: "Z1118", text: "0.014 analysis process decision", data: { name: "Z1118", level: 1, percentage: 0.01425107025188889 }, children: []
        }, {
          id: "Z1116", text: "0.032 humano humana consumo", data: { name: "Z1116", level: 1, percentage: 0.03220938024399798 }, children: []
        }, {
          id: "Z1115", text: "0.235 region muestreo municipio clase", data: { name: "Z1115", level: 1, percentage: 0.23545367133234082 }, children: []
        }, {
          id: "Z1120", text: "0.000 modelos estimar", data: { name: "Z1120", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1114", text: "0.000 aguas rio", data: { name: "Z1114", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1121", text: "0.049 regresion lineal variable_ funcion", data: { name: "Z1121", level: 1, percentage: 0.048515188652894434 }, children: []
        }, {
          id: "Z1119", text: "0.051 estandar model lenguaje permiten procedimiento propuestas utilizacion", data: { name: "Z1119", level: 1, percentage: 0.050714822114624594 }, children: []
        }]
    }, {
      id: "Z229", text: "0.066 especies especie genero diversidad familia bosque familias", data: { name: "Z229", level: 2, percentage: 0.06589038144644584 }, children: [{
          id: "Z1109", text: "0.090 especies identificacion estudiante", data: { name: "Z1109", level: 1, percentage: 0.09000939696529674 }, children: []
        }, {
          id: "Z1110", text: "0.054 diversidad bosque index", data: { name: "Z1110", level: 1, percentage: 0.05400619816603805 }, children: []
        }, {
          id: "Z1111", text: "0.087 especie individuos evidencio comercial arte sintomas dato", data: { name: "Z1111", level: 1, percentage: 0.08659581821721976 }, children: []
        }, {
          id: "Z1113", text: "0.000 familias familia", data: { name: "Z1113", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1112", text: "0.000 mujeres genero", data: { name: "Z1112", level: 1, percentage: 0.0 }, children: []
        }]
    }]
}, {
  id: "Z31", text: "0.107 mayor diferencia significativas alta presento estadisticamente encontraron", data: { name: "Z31", level: 3, percentage: 0.10712922782961294 }, children: [{
      id: "Z21", text: "0.153 alta variacion nivel coeficiente determinacion velocidad factor", data: { name: "Z21", level: 2, percentage: 0.15340874078095096 }, children: [{
          id: "Z14", text: "0.068 componentes componente principales lineas", data: { name: "Z14", level: 1, percentage: 0.06771282163374912 }, children: []
        }, {
          id: "Z12", text: "0.413 alta nivel coeficiente determinacion factor factore didactica", data: { name: "Z12", level: 1, percentage: 0.4131829003872986 }, children: []
        }, {
          id: "Z11", text: "0.075 velocidad rango presion medio carbon nivele equipo", data: { name: "Z11", level: 1, percentage: 0.07515743906677966 }, children: []
        }, {
          id: "Z13", text: "0.186 variacion social realidad", data: { name: "Z13", level: 1, percentage: 0.18639822736135966 }, children: []
        }]
    }, {
      id: "Z23", text: "0.231 objetivo principal utilizo tiempo seleccion presente-estudio aplico", data: { name: "Z23", level: 2, percentage: 0.23113023910185754 }, children: [{
          id: "Z18", text: "0.184 objetivo tiempo seleccion presente-estudio presentar cuatro lograr", data: { name: "Z18", level: 1, percentage: 0.1843598087010703 }, children: []
        }, {
          id: "Z19", text: "0.236 principal virus falla instituto complejo luz", data: { name: "Z19", level: 1, percentage: 0.23550890084475012 }, children: []
        }, {
          id: "Z17", text: "0.182 utilizo aplico corte tercer adecuada aplicada comunidades", data: { name: "Z17", level: 1, percentage: 0.18235594710960207 }, children: []
        }]
    }, {
      id: "Z22", text: "0.083 diferencia significativas estadisticamente encontraron menor asociacion", data: { name: "Z22", level: 2, percentage: 0.08254284052758276 }, children: [{
          id: "Z15", text: "0.045 significativas estadisticamente asociacion", data: { name: "Z15", level: 1, percentage: 0.04505037219587193 }, children: []
        }, {
          id: "Z16", text: "0.099 diferencia encontraron menor", data: { name: "Z16", level: 1, percentage: 0.09931919229241878 }, children: []
        }]
    }, {
      id: "Z24", text: "0.173 mayor presento capacidad evaluacion significativa promedio almacenamiento", data: { name: "Z24", level: 2, percentage: 0.17269351289728888 }, children: [{
          id: "Z114", text: "0.000 calidad evaluacion", data: { name: "Z114", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z110", text: "0.000 promedio mayor", data: { name: "Z110", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z112", text: "0.024 almacenamiento perdida elementos", data: { name: "Z112", level: 1, percentage: 0.023673797992926054 }, children: []
        }, {
          id: "Z113", text: "0.236 capacidad pueden frente medios maestria contribuir posterior", data: { name: "Z113", level: 1, percentage: 0.23560979346776306 }, children: []
        }, {
          id: "Z111", text: "0.045 presento significativa indice", data: { name: "Z111", level: 1, percentage: 0.04464876652315758 }, children: []
        }]
    }, {
      id: "Z25", text: "0.025 proteina respuesta proteinas leche representa obtenido agua", data: { name: "Z25", level: 2, percentage: 0.02548970071070375 }, children: [{
          id: "Z115", text: "0.021 proteina respuesta leche", data: { name: "Z115", level: 1, percentage: 0.02146248312713726 }, children: []
        }, {
          id: "Z116", text: "0.108 proteinas representa obtenido agua perfil yuca area", data: { name: "Z116", level: 1, percentage: 0.10804575242458561 }, children: []
        }]
    }, {
      id: "Z26", text: "0.238 grupo cada experimental laboratorio valores grupos diseno", data: { name: "Z26", level: 2, percentage: 0.23839590941227023 }, children: [{
          id: "Z117", text: "0.000 grupo experimental", data: { name: "Z117", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z118", text: "0.219 cada valores grupos", data: { name: "Z118", level: 1, percentage: 0.21914784706517754 }, children: []
        }, {
          id: "Z119", text: "0.259 laboratorio diseno campo reaccion superficial patron estructural", data: { name: "Z119", level: 1, percentage: 0.25941185611714546 }, children: []
        }]
    }]
}, {
  id: "Z34", text: "0.138 efecto evaluo cultivo concentracion produccion presentaron determino", data: { name: "Z34", level: 3, percentage: 0.13825327019348652 }, children: [{
      id: "Z214", text: "0.031 actividad acido extracto antioxidante", data: { name: "Z214", level: 2, percentage: 0.03127028393556008 }, children: [{
          id: "Z142", text: "0.000 actividad antioxidante", data: { name: "Z142", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z143", text: "0.000 extracto acido", data: { name: "Z143", level: 1, percentage: 0.0 }, children: []
        }]
    }, {
      id: "Z213", text: "0.145 evaluo cultivo concentracion produccion presentaron determino respectivamente", data: { name: "Z213", level: 2, percentage: 0.1449826578611328 }, children: [{
          id: "Z137", text: "0.057 cultivo potencial tratamientos crecimiento", data: { name: "Z137", level: 1, percentage: 0.05660010560909326 }, children: []
        }, {
          id: "Z139", text: "0.101 concentracion determino vitro", data: { name: "Z139", level: 1, percentage: 0.10130415576293621 }, children: []
        }, {
          id: "Z140", text: "0.082 respectivamente evaluaron dias planta dosis color fruto", data: { name: "Z140", level: 1, percentage: 0.08249179216864296 }, children: []
        }, {
          id: "Z136", text: "0.123 produccion plantas sustrato temperaturas", data: { name: "Z136", level: 1, percentage: 0.1234210612860441 }, children: []
        }, {
          id: "Z138", text: "0.000 presentaron evaluo", data: { name: "Z138", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z141", text: "0.000 evaluar evaluado", data: { name: "Z141", level: 1, percentage: 0.0 }, children: []
        }]
    }, {
      id: "Z212", text: "0.189 efecto observo disminucion realizaron incremento diferente efectos", data: { name: "Z212", level: 2, percentage: 0.18888210460093774 }, children: [{
          id: "Z133", text: "0.000 sido efectos", data: { name: "Z133", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z135", text: "0.139 disminucion incremento ensayos", data: { name: "Z135", level: 1, percentage: 0.13918626381903917 }, children: []
        }, {
          id: "Z134", text: "0.221 efecto observo realizaron diferente nitrogeno embargo", data: { name: "Z134", level: 1, percentage: 0.22129414646403003 }, children: []
        }]
    }]
}, {
  id: "Z311", text: "0.179 sistema sistemas parametros energia metodo obtener algoritmo", data: { name: "Z311", level: 3, percentage: 0.179026090353456 }, children: [{
      id: "Z241", text: "0.089 algoritmo solucion mejorar problemas optimizacion tesis propone", data: { name: "Z241", level: 2, percentage: 0.0893743493894504 }, children: [{
          id: "Z1169", text: "0.000 propone algoritmo", data: { name: "Z1169", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1167", text: "0.047 problemas tesis soluciones estructuras", data: { name: "Z1167", level: 1, percentage: 0.046585184781644175 }, children: []
        }, {
          id: "Z1168", text: "0.130 solucion mejorar optimizacion flujo mejoramiento adsorcion", data: { name: "Z1168", level: 1, percentage: 0.13029183451749132 }, children: []
        }]
    }, {
      id: "Z240", text: "0.124 sistema sistemas energia operacion simulacion potencia electrica", data: { name: "Z240", level: 2, percentage: 0.12377259650036963 }, children: [{
          id: "Z1166", text: "0.000 electrica energia", data: { name: "Z1166", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1164", text: "0.139 sistemas carga implementar gran permitan", data: { name: "Z1164", level: 1, percentage: 0.13857507763740864 }, children: []
        }, {
          id: "Z1165", text: "0.030 potencia corriente considerando", data: { name: "Z1165", level: 1, percentage: 0.03013818347828762 }, children: []
        }, {
          id: "Z1163", text: "0.000 sistema transporte", data: { name: "Z1163", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1162", text: "0.230 operacion simulacion system", data: { name: "Z1162", level: 1, percentage: 0.23026715211474666 }, children: []
        }]
    }, {
      id: "Z243", text: "0.290 metodo caracterizacion tecnica tecnicas metodos utilizado presenta", data: { name: "Z243", level: 2, percentage: 0.2903030893107511 }, children: [{
          id: "Z1176", text: "0.000 presentan presenta", data: { name: "Z1176", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1173", text: "0.230 tecnica metodos utilizado ingenieria modelacion caracterizar fisico", data: { name: "Z1173", level: 1, percentage: 0.23040283167949477 }, children: []
        }, {
          id: "Z1175", text: "0.261 caracterizacion tecnicas aislamiento politico", data: { name: "Z1175", level: 1, percentage: 0.26136610159393586 }, children: []
        }, {
          id: "Z1174", text: "0.081 metodo computacional aplicaciones clasificacion aire definir linea", data: { name: "Z1174", level: 1, percentage: 0.0813353795484219 }, children: []
        }]
    }, {
      id: "Z242", text: "0.242 parametros obtener obtencion estimacion eficiencia producto ajuste", data: { name: "Z242", level: 2, percentage: 0.24173786145387566 }, children: [{
          id: "Z1172", text: "0.129 obtencion numero degradacion frutos ciudad regiones presente", data: { name: "Z1172", level: 1, percentage: 0.12877362859907818 }, children: []
        }, {
          id: "Z1171", text: "0.096 parametros estimacion ajuste", data: { name: "Z1171", level: 1, percentage: 0.09648139785309556 }, children: []
        }, {
          id: "Z1170", text: "0.124 obtener eficiencia producto valor etapas entrevistas", data: { name: "Z1170", level: 1, percentage: 0.1244939130783713 }, children: []
        }]
    }]
}, {
  id: "Z33", text: "0.095 estudiantes aprendizaje ensenanza estudiantes-grado educacion aula institucion-educativa", data: { name: "Z33", level: 3, percentage: 0.09496216760372687 }, children: [{
      id: "Z211", text: "0.089 estudiantes aprendizaje estudiantes-grado ensenanza-aprendizaje escuela todas nueva", data: { name: "Z211", level: 2, percentage: 0.08861021907928877 }, children: [{
          id: "Z132", text: "0.070 estudiantes ensenanza-aprendizaje escuela todas nueva", data: { name: "Z132", level: 1, percentage: 0.07038019413744817 }, children: []
        }, {
          id: "Z131", text: "0.000 estudiantes-grado aprendizaje", data: { name: "Z131", level: 1, percentage: 0.0 }, children: []
        }]
    }, {
      id: "Z210", text: "0.095 ensenanza educacion aula institucion-educativa conceptos grado escolar", data: { name: "Z210", level: 2, percentage: 0.09459396086983582 }, children: [{
          id: "Z130", text: "0.272 concepto colegio conocimiento aplicacion desarrollar total encontro", data: { name: "Z130", level: 1, percentage: 0.2719656020256001 }, children: []
        }, {
          id: "Z127", text: "0.096 ensenanza escolar secundaria primaria", data: { name: "Z127", level: 1, percentage: 0.09643592095610055 }, children: []
        }, {
          id: "Z128", text: "0.088 educacion institucion-educativa basica academico contexto resolucion", data: { name: "Z128", level: 1, percentage: 0.08821505322453202 }, children: []
        }, {
          id: "Z129", text: "0.094 aula conceptos grado", data: { name: "Z129", level: 1, percentage: 0.09355981539725289 }, children: []
        }]
    }]
}, {
  id: "Z36", text: "0.166 informacion tecnologias datos comunicacion segundo red cualitativo", data: { name: "Z36", level: 3, percentage: 0.16565182184561067 }, children: [{
      id: "Z224", text: "0.079 segundo primer tres ultimo momento constituye obra", data: { name: "Z224", level: 2, percentage: 0.0785308192637027 }, children: [{
          id: "Z183", text: "0.063 segundo tres ultimo momento", data: { name: "Z183", level: 1, percentage: 0.06294227013446471 }, children: []
        }, {
          id: "Z182", text: "0.125 primer constituye obra identidad identificar climatico ciclo", data: { name: "Z182", level: 1, percentage: 0.12463260794368422 }, children: []
        }]
    }, {
      id: "Z227", text: "0.081 suelo suelos zonas cambios zona precipitacion valle", data: { name: "Z227", level: 2, percentage: 0.08089532891519899 }, children: [{
          id: "Z1103", text: "0.048 suelo suelos cauca", data: { name: "Z1103", level: 1, percentage: 0.04813798853967289 }, children: []
        }, {
          id: "Z1104", text: "0.000 valle zonas", data: { name: "Z1104", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1106", text: "0.126 cambios precipitacion posibles despues cuale podria diferentes", data: { name: "Z1106", level: 1, percentage: 0.12605079473818315 }, children: []
        }, {
          id: "Z1105", text: "0.074 zona sur humedad relaciones", data: { name: "Z1105", level: 1, percentage: 0.07390315531071563 }, children: []
        }]
    }, {
      id: "Z221", text: "0.141 datos literatura basis distribucion procesamiento resultado comportamiento", data: { name: "Z221", level: 2, percentage: 0.1407866240293913 }, children: [{
          id: "Z169", text: "0.358 datos distribucion procesamiento resultado comportamiento torno", data: { name: "Z169", level: 1, percentage: 0.3579948243725851 }, children: []
        }, {
          id: "Z168", text: "0.247 literatura basis imagenes encontrar igualmente alrededor", data: { name: "Z168", level: 1, percentage: 0.24672832375432147 }, children: []
        }]
    }, {
      id: "Z223", text: "0.147 luego posteriormente realizar necesario primero alimentaria cuales", data: { name: "Z223", level: 2, percentage: 0.14691994312841564 }, children: [{
          id: "Z180", text: "0.000 determinar estadistico", data: { name: "Z180", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z181", text: "0.052 revision realiza proponer", data: { name: "Z181", level: 1, percentage: 0.051984239048321446 }, children: []
        }, {
          id: "Z172", text: "0.227 luego posteriormente primero tre", data: { name: "Z172", level: 1, percentage: 0.2268685334646049 }, children: []
        }, {
          id: "Z175", text: "0.035 reconocimiento discapacidad cambio esquema", data: { name: "Z175", level: 1, percentage: 0.03489195517305385 }, children: []
        }, {
          id: "Z173", text: "0.000 necesario realizar", data: { name: "Z173", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z179", text: "0.039 aumento resistencia microscopia", data: { name: "Z179", level: 1, percentage: 0.03884332146734835 }, children: []
        }, {
          id: "Z174", text: "0.101 mecanismo formacion papel estres tejido significativamente misma", data: { name: "Z174", level: 1, percentage: 0.10114538334911584 }, children: []
        }, {
          id: "Z178", text: "0.106 importante estudios principalmente encuentra prevencion deteccion descripcion", data: { name: "Z178", level: 1, percentage: 0.10592025195721474 }, children: []
        }, {
          id: "Z176", text: "0.010 alimentaria alimentos san", data: { name: "Z176", level: 1, percentage: 0.009570969127870933 }, children: []
        }, {
          id: "Z177", text: "0.584 cuales caracteristicas igual", data: { name: "Z177", level: 1, percentage: 0.5836775397693268 }, children: []
        }]
    }, {
      id: "Z226", text: "0.100 cualitativo relacion intervencion existe bienestar atencion familiar", data: { name: "Z226", level: 2, percentage: 0.09956607390166873 }, children: [{
          id: "Z1102", text: "0.000 bienestar intervencion", data: { name: "Z1102", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1101", text: "0.033 cualitativo familiar cabo actualmente", data: { name: "Z1101", level: 1, percentage: 0.0325548791205066 }, children: []
        }, {
          id: "Z199", text: "0.111 relacion correlacion cuidado factores incidencia presentacion usuarios", data: { name: "Z199", level: 1, percentage: 0.11075220872260598 }, children: []
        }, {
          id: "Z1100", text: "0.101 existe atencion ciudad-bogota", data: { name: "Z1100", level: 1, percentage: 0.10113289456918645 }, children: []
        }]
    }, {
      id: "Z225", text: "0.135 practica teoria tema profesional dar propuesto temas", data: { name: "Z225", level: 2, percentage: 0.13500105347521857 }, children: [{
          id: "Z188", text: "0.069 propuesto basado propuesta", data: { name: "Z188", level: 1, percentage: 0.06883396004766779 }, children: []
        }, {
          id: "Z187", text: "0.082 objetivos acuerdo riesgos mundial falta cuyo inicialmente", data: { name: "Z187", level: 1, percentage: 0.0824123459674592 }, children: []
        }, {
          id: "Z193", text: "0.045 dar conocer documento construir especial interior ejecucion", data: { name: "Z193", level: 1, percentage: 0.04486025032201621 }, children: []
        }, {
          id: "Z190", text: "0.004 validez inclusion aporte rural", data: { name: "Z190", level: 1, percentage: 0.003973314567899966 }, children: []
        }, {
          id: "Z195", text: "0.079 productividad industrial eficiente mezclas", data: { name: "Z195", level: 1, percentage: 0.0789643610757408 }, children: []
        }, {
          id: "Z194", text: "0.098 organizacion empresarial vision visual", data: { name: "Z194", level: 1, percentage: 0.09802377140396837 }, children: []
        }, {
          id: "Z184", text: "0.000 profesional practica", data: { name: "Z184", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z197", text: "0.190 resultado-obtenido pruebas adicion", data: { name: "Z197", level: 1, percentage: 0.1897986663503442 }, children: []
        }, {
          id: "Z196", text: "0.089 tema temas ciencias", data: { name: "Z196", level: 1, percentage: 0.08851071640908947 }, children: []
        }, {
          id: "Z185", text: "0.000 teorias teoria", data: { name: "Z185", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z198", text: "0.079 asociados identificaron menos relacionadas posible agentes aspectos", data: { name: "Z198", level: 1, percentage: 0.07945341337351014 }, children: []
        }, {
          id: "Z186", text: "0.125 vez aspecto generacion pesar dado investigaciones tipos", data: { name: "Z186", level: 1, percentage: 0.12450211310196345 }, children: []
        }, {
          id: "Z189", text: "0.035 teorico categorias competencia tener integracion infraestructura logro", data: { name: "Z189", level: 1, percentage: 0.034711491399362894 }, children: []
        }, {
          id: "Z191", text: "0.000 espacial escala", data: { name: "Z191", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z192", text: "0.051 asociado busca digital gen interpretacion", data: { name: "Z192", level: 1, percentage: 0.05137391426494837 }, children: []
        }]
    }, {
      id: "Z222", text: "0.067 informacion tecnologias comunicacion red uso proyecto", data: { name: "Z222", level: 2, percentage: 0.066973052263664 }, children: [{
          id: "Z171", text: "0.037 tecnologias comunicacion uso", data: { name: "Z171", level: 1, percentage: 0.03690237788672019 }, children: []
        }, {
          id: "Z170", text: "0.342 informacion red proyecto", data: { name: "Z170", level: 1, percentage: 0.3416826410633002 }, children: []
        }]
    }, {
      id: "Z228", text: "0.127 dinamica modelo ecuaciones prediccion dinamicas permite muestran", data: { name: "Z228", level: 2, percentage: 0.1272047393732559 }, children: [{
          id: "Z1108", text: "0.177 dinamica dinamicas permite muestran conjunto cualquier", data: { name: "Z1108", level: 1, percentage: 0.17726316611469922 }, children: []
        }, {
          id: "Z1107", text: "0.143 modelo ecuaciones prediccion", data: { name: "Z1107", level: 1, percentage: 0.14297867643214068 }, children: []
        }]
    }]
}, {
  id: "Z39", text: "0.108 pacientes paciente enfermedad salud clinica conclusiones descriptivo", data: { name: "Z39", level: 3, percentage: 0.10814729932989836 }, children: [{
      id: "Z236", text: "0.126 enfermedad clinica conclusiones descriptivo hospital poblacion clinico", data: { name: "Z236", level: 2, percentage: 0.12597826597670259 }, children: [{
          id: "Z1144", text: "0.043 enfermedad ano cronica", data: { name: "Z1144", level: 1, percentage: 0.043072599202593355 }, children: []
        }, {
          id: "Z1145", text: "0.053 hospital bogota siendo", data: { name: "Z1145", level: 1, percentage: 0.053011007181658465 }, children: []
        }, {
          id: "Z1148", text: "0.079 frecuente hombre asociada cuanto situacion virtual software", data: { name: "Z1148", level: 1, percentage: 0.07918272032105805 }, children: []
        }, {
          id: "Z1149", text: "0.000 conclusiones capitulo", data: { name: "Z1149", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1147", text: "0.121 clinico sindrome personal sensibilidad universidad-nacional unidad trabajo-presenta", data: { name: "Z1147", level: 1, percentage: 0.12108052946231712 }, children: []
        }, {
          id: "Z1146", text: "0.236 diagnostico causa manejo segun", data: { name: "Z1146", level: 1, percentage: 0.23609185480422853 }, children: []
        }, {
          id: "Z1151", text: "0.142 poblacion edad poblaciones", data: { name: "Z1151", level: 1, percentage: 0.1421463082436202 }, children: []
        }, {
          id: "Z1150", text: "0.166 mortalidad conclusion frecuencia control", data: { name: "Z1150", level: 1, percentage: 0.16587664308256259 }, children: []
        }, {
          id: "Z1143", text: "0.104 clinica descriptivo casos criterios", data: { name: "Z1143", level: 1, percentage: 0.10431168248837382 }, children: []
        }]
    }, {
      id: "Z237", text: "0.083 salud salud-publica enfermeria persona enfermedades describir percepcion", data: { name: "Z237", level: 2, percentage: 0.08264486262720717 }, children: [{
          id: "Z1154", text: "0.000 salud-publica enfermedades", data: { name: "Z1154", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1153", text: "0.129 persona describir percepcion instrumento encuesta laboral mundo", data: { name: "Z1153", level: 1, percentage: 0.12906364779085805 }, children: []
        }, {
          id: "Z1152", text: "0.000 salud enfermeria", data: { name: "Z1152", level: 1, percentage: 0.0 }, children: []
        }]
    }, {
      id: "Z235", text: "0.088 pacientes paciente prevalencia riesgo tratamiento infeccion consulta", data: { name: "Z235", level: 2, percentage: 0.08803141796888865 }, children: [{
          id: "Z1142", text: "0.058 paciente tratamiento consulta servicio", data: { name: "Z1142", level: 1, percentage: 0.058439507683159274 }, children: []
        }, {
          id: "Z1141", text: "0.089 pacientes prevalencia riesgo infeccion transmision", data: { name: "Z1141", level: 1, percentage: 0.08886997802587579 }, children: []
        }]
    }]
}, {
  id: "Z38", text: "0.141 temperatura propiedades mostraron condiciones contenido mediante composicion", data: { name: "Z38", level: 3, percentage: 0.14068728005313885 }, children: [{
      id: "Z233", text: "0.167 mostraron fase dos compuesto obtuvieron valore quimica", data: { name: "Z233", level: 2, percentage: 0.16691366797894122 }, children: [{
          id: "Z1133", text: "0.161 obtuvieron valore quimica obtenidos", data: { name: "Z1133", level: 1, percentage: 0.16131999509618458 }, children: []
        }, {
          id: "Z1132", text: "0.210 mostraron mejor respecto", data: { name: "Z1132", level: 1, percentage: 0.21021795045027505 }, children: []
        }, {
          id: "Z1134", text: "0.065 periodo diferencias peso historia poder adaptacion importantes", data: { name: "Z1134", level: 1, percentage: 0.06496126692628937 }, children: []
        }, {
          id: "Z1130", text: "0.000 compuesto fase", data: { name: "Z1130", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1131", text: "0.000 primera dos", data: { name: "Z1131", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1136", text: "0.069 relacionada eventos exposicion protocolo hizo programas responsabilidad", data: { name: "Z1136", level: 1, percentage: 0.06915643924969994 }, children: []
        }, {
          id: "Z1137", text: "0.013 medidas soporte profesionales", data: { name: "Z1137", level: 1, percentage: 0.012752602718221356 }, children: []
        }, {
          id: "Z1135", text: "0.221 variedad hipotesis mecanismos probabilidad paso problema cuerpo", data: { name: "Z1135", level: 1, percentage: 0.22109845876161274 }, children: []
        }]
    }, {
      id: "Z234", text: "0.137 temperatura propiedades condiciones mediante contenido composicion compuestos", data: { name: "Z234", level: 2, percentage: 0.13740330335522216 }, children: [{
          id: "Z1139", text: "0.106 temperatura condiciones mediante material", data: { name: "Z1139", level: 1, percentage: 0.10646496939220469 }, children: []
        }, {
          id: "Z1140", text: "0.072 composicion mezcla rayos tamano estabilidad fibra permitio", data: { name: "Z1140", level: 1, percentage: 0.07175235399433459 }, children: []
        }, {
          id: "Z1138", text: "0.094 propiedades compuestos contenido peliculas", data: { name: "Z1138", level: 1, percentage: 0.09393768456819165 }, children: []
        }]
    }]
}, {
  id: "Z310", text: "0.078 politica politicas publica publicas cultural gobierno formas", data: { name: "Z310", level: 3, percentage: 0.07826517841923901 }, children: [{
      id: "Z238", text: "0.088 politica politicas publica publicas marco gobierno sociales", data: { name: "Z238", level: 2, percentage: 0.08787385445549205 }, children: [{
          id: "Z1156", text: "0.056 publica publicas marco actores analizar", data: { name: "Z1156", level: 1, percentage: 0.056309658466357625 }, children: []
        }, {
          id: "Z1157", text: "0.057 politica gobierno acciones", data: { name: "Z1157", level: 1, percentage: 0.056866221820130895 }, children: []
        }, {
          id: "Z1155", text: "0.000 ordenamiento politicas", data: { name: "Z1155", level: 1, percentage: 0.0 }, children: []
        }, {
          id: "Z1158", text: "0.117 sociales derecho ejercicio principios escenario local comunidad", data: { name: "Z1158", level: 1, percentage: 0.11720966116215899 }, children: []
        }]
    }, {
      id: "Z239", text: "0.149 cultural cultura formas vida perspectiva publico hace", data: { name: "Z239", level: 2, percentage: 0.14886858062200317 }, children: [{
          id: "Z1161", text: "0.120 experiencias diversas planificacion haciendo muestra dano departamento", data: { name: "Z1161", level: 1, percentage: 0.12014894709268366 }, children: []
        }, {
          id: "Z1159", text: "0.260 formas vida perspectiva publico hace proyectos sujeto", data: { name: "Z1159", level: 1, percentage: 0.26048844724012216 }, children: []
        }, {
          id: "Z1160", text: "0.000 cultura cultural", data: { name: "Z1160", level: 1, percentage: 0.0 }, children: []
        }]
    }]
}, {
  id: "Z32", text: "0.074 docente estrategia docentes competencias educativo pensamiento comprension", data: { name: "Z32", level: 3, percentage: 0.07444433845969849 }, children: [{
      id: "Z28", text: "0.044 docente docentes educativo instituciones construccion universidad discurso", data: { name: "Z28", level: 2, percentage: 0.04354559541971968 }, children: [{
          id: "Z124", text: "0.169 docente instituciones construccion discurso traves", data: { name: "Z124", level: 1, percentage: 0.1691440887516604 }, children: []
        }, {
          id: "Z123", text: "0.102 docentes educativo investigacion universidad sociale entender", data: { name: "Z123", level: 1, percentage: 0.10162084259526379 }, children: []
        }]
    }, {
      id: "Z29", text: "0.160 herramienta herramientas finalmente metodologica util fin empresa", data: { name: "Z29", level: 2, percentage: 0.16034446909301825 }, children: [{
          id: "Z125", text: "0.299 herramientas finalmente metodologica fin empresa principale redes", data: { name: "Z125", level: 1, percentage: 0.29877411526754216 }, children: []
        }, {
          id: "Z126", text: "0.000 herramienta util", data: { name: "Z126", level: 1, percentage: 0.0 }, children: []
        }]
    }, {
      id: "Z27", text: "0.151 estrategia competencias comprension pensamiento estrategias actividades innovacion", data: { name: "Z27", level: 2, percentage: 0.15052628112319708 }, children: [{
          id: "Z121", text: "0.163 estrategia estrategias actividades", data: { name: "Z121", level: 1, percentage: 0.16345667894253213 }, children: []
        }, {
          id: "Z122", text: "0.100 competencias pensamiento idea entorno proceso", data: { name: "Z122", level: 1, percentage: 0.09984559319967361 }, children: []
        }, {
          id: "Z120", text: "0.063 comprension innovacion capacidades pregunta fundamental", data: { name: "Z120", level: 1, percentage: 0.06308595215024541 }, children: []
        }]
    }]
}
];
